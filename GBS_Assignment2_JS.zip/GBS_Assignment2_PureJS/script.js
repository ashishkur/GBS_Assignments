fetch('./content.json',{
    headers : { 
      'Content-Type': 'application/json',
      'Accept': 'application/json'
     }
   })
   .then(
       res=>{
           res.json().then(
               data=>{
                   console.log(data.subjects);
                   if(data.subjects.length > 0){
                      let temp = ""; 
                      data.subjects.forEach((s) => {
                          temp += "<tr>";
                          temp += "<td>" + s.heading + "</td>";

                          temp += "<td>" + s.description + "</td>";

                          temp += "<td>" + "<img src=" + s.image + "></td>";

                          temp += "<td>" + "<a href='https://www.w3schools.com/'>" + s.anchor + "</a>" + "</td>";

                          temp += "</tr>";
                      })
                      document.getElementById("demo").innerHTML = temp;
                   }
               }
           )
       }
   )