$(document).ready(function() {
    $.getJSON("content.json",
        function(data) {
            var subjects = '';

            $.each(data.subjects, function(key, value) {

                subjects += '<tr>';
                subjects += '<td>' +
                    value.heading + '</td>';

                subjects += '<td>' +
                    value.description + '</td>';

                subjects += '<td>' + '<img src=' + value.image + '>'
                '</td>';

                subjects += '<td>' + '<a href="https://www.w3schools.com/">' + value.anchor + '</a>' + '</td>';

                subjects += '</tr>';
            });

            $('#table').append(subjects);
        });
});